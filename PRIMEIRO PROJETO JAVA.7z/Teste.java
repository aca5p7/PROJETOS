/*
 * Faça um programa que receba o ano de nascimento de uma pessoa e o ano atual,
 * calcule e mostre:
 *
 * a) a idade dessa pessoa;
 * b) quantos anos ela terá em 2050
 *
 */

package com.mycompany.teste;

/**
 *
 * @author user1
 */
public class Teste {

    public static void main(String[] args) {
               // declarando as variaveis
        
       int idadeatual, idadefutura, nasc, futuro, presente;
   
       // valor da variaveis
       
       nasc = 2002;
       futuro = 2050;
       presente = 2023;
       
       // calculo de idade
       
       idadeatual = presente - nasc;
       idadefutura = (futuro - presente) + idadeatual ; 
       
       //imprimir o resultado
      System.out.println("Idade atual: " + idadeatual );
      
      System.out.println("Idade futura: " + idadefutura );  
      
    }
}
